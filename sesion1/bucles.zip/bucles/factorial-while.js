let i = 1;
let factorial = 1;
while (i<=10) {
    factorial = i * factorial;
    i++;
    console.log(factorial);
}