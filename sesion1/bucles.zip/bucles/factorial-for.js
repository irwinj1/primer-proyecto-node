
let resultFactorial=1;
for (let index = 2; index <= 10; index++) {
  
   resultFactorial = index * resultFactorial
    console.log(resultFactorial);
}
