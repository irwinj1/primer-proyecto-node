const nombre = 'Irwin Guardado';
const edad = 33;
const eresDesarrolador = false;
const fecha_nacimiento = new Date("febrary 12 1989");
const libro = {
    titulo:'Pensamiento filosófico contemporáneo',
    autor:'Francisco Arenas-Dolz',
    fecha:new Date('january 1 2015'),
    url:'https://openlibra.com/es/book/pensamiento-filosofico-contemporaneo'
}
console.log(fecha_nacimiento);